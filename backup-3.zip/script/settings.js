// ============================================================
//  settings.js  –  HB Weather Dashboard
//  Handles:
//    1. Temperature unit  :  Celsius  ↔  Fahrenheit
//    2. Time format       :  12-hour  ↔  24-hour
// ============================================================

const SETTINGS_KEY = "hb_weather_settings";
const unitToggle = document.querySelector("#unitToggle");
const timeToggle = document.querySelector("#timeToggle");

const defaultSettings = {
  tempUnit: "C",
  timeFormat: "12h",
};

let settings = { ...defaultSettings };

export function loadSettings() {
  try {
    const stored = localStorage.getItem(SETTINGS_KEY);

    if (stored) {
      settings = {
        ...defaultSettings,
        ...JSON.parse(stored),
      };
    } else {
      settings = { ...defaultSettings };
      localStorage.setItem(SETTINGS_KEY, JSON.stringify(settings));
    }
    
    if (timeToggle) timeToggle.checked = settings.timeFormat === "24h";
    // Assuming 'C' is unchecked and 'F' is checked for the unit toggle
    if (unitToggle) unitToggle.checked = settings.tempUnit === "F";

    return settings;
  } catch (error) {
    console.error(error);
    return settings;
  }
}

if (unitToggle) {
  unitToggle.addEventListener("change", () => {
    settings.tempUnit = settings.tempUnit === "C" ? "F" : "C";
    localStorage.setItem(SETTINGS_KEY, JSON.stringify(settings));
    
    // Dispatch event to refresh weather with new unit
    document.dispatchEvent(new CustomEvent("settingsChanged", { detail: { type: "unit" } }));
  });
}

if (timeToggle) {
  timeToggle.addEventListener("change", () => {
    settings.timeFormat = timeToggle.checked ? "24h" : "12h";
    localStorage.setItem(SETTINGS_KEY, JSON.stringify(settings));
    
    // Dispatch event to re-render forecast times
    document.dispatchEvent(new CustomEvent("settingsChanged", { detail: { type: "time" } }));
  });
}

export function getSettings() {
  return settings;
}

export function getTemperatureUints() {
  return settings.tempUnit === "C" ? "metric" : "imperial";
}

export function getTemperatureSymbol() {
  return settings.tempUnit === "C" ? "°C" : "°F";
}
