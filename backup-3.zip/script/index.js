// ============================================================
//  index.js  –  HB Weather Dashboard
//  Main entry point
// ============================================================

import { loadSettings } from "./settings.js";
import { getCurrentCity, searchWeather } from "./weather.js";

const searchInput = document.querySelector("#search-weather");

// ── Event Listeners ─────────────────────────────────────────

// Search city on Enter key
searchInput.addEventListener("keydown", (e) => {
  if (e.key === "Enter") {
    searchWeather(searchInput.value);
  }
});

// Fetch current city weather on initial load and initialize settings
window.addEventListener("DOMContentLoaded", () => {
  loadSettings();
  getCurrentCity();
});

// Refresh weather data when the unit setting is toggled
document.addEventListener("settingsChanged", (e) => {
  if (e.detail && e.detail.type === "unit") {
    // Determine the city to search. If user searched manually, use that.
    // Otherwise fallback to IP-based city.
    if (searchInput.value.trim()) {
      searchWeather(searchInput.value);
    } else {
      getCurrentCity();
    }
  }
});