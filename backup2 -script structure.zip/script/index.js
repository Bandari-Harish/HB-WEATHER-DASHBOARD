// ============================================================
//  index.js  –  HB Weather Dashboard
//  Main entry point
// ============================================================

import { getCurrentCity, searchWeather } from "./weather.js";

const searchInput = document.querySelector("#search-weather");

// ── Event Listeners ─────────────────────────────────────────

// Search city on Enter key
searchInput.addEventListener("keydown", (e) => {
  if (e.key === "Enter") {
    searchWeather(searchInput.value);
  }
});

// Fetch current city weather on initial load and initialize charts
window.addEventListener("DOMContentLoaded", () => {
  getCurrentCity();
});