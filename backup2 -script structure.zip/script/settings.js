// ============================================================
//  settings.js  –  HB Weather Dashboard
//  Handles:
//    1. Temperature unit  :  Celsius  ↔  Fahrenheit
//    2. Time format       :  12-hour  ↔  24-hour
// ============================================================

// ── Persisted preferences ────────────────────────────────────
const SETTINGS_KEY = "hb_weather_settings";

const defaultSettings = {
  tempUnit: "C",      // "C" | "F"
  timeFormat: "12h",  // "12h" | "24h"
};


export function loadSettings() {
  try {
    const stored = localStorage.getItem(SETTINGS_KEY);
    return stored ? { ...defaultSettings, ...JSON.parse(stored) } : { ...defaultSettings };
  } catch {
    return { ...defaultSettings };
  }
}

export function saveSettings(settings) {
  localStorage.setItem(SETTINGS_KEY, JSON.stringify(settings));
}

export let currentSettings = loadSettings();


// ── Temperature Conversions ──────────────────────────────────


export function celsiusToFahrenheit(celsius) {
  return (celsius * 9) / 5 + 32;
}


export function fahrenheitToCelsius(fahrenheit) {
  return ((fahrenheit - 32) * 5) / 9;
}


export function formatTemp(celsius, showUnit = true) {
  if (currentSettings.tempUnit === "F") {
    const f = celsiusToFahrenheit(celsius);
    return `${Math.round(f)}${showUnit ? "°F" : "°"}`;
  }
  return `${Math.round(celsius)}${showUnit ? "°C" : "°"}`;
}


// ── Time-format Conversions ──────────────────────────────────

export function formatTime(unixSeconds, label = "") {
  if (label) return label;

  const date = new Date(unixSeconds * 1000);

  if (currentSettings.timeFormat === "24h") {
    // Zero-padded HH:MM
    const hh = String(date.getHours()).padStart(2, "0");
    const mm = String(date.getMinutes()).padStart(2, "0");
    return `${hh}:${mm}`;
  }

  // 12-hour  →  "3 PM" / "11:30 AM"
  return date.toLocaleTimeString([], {
    hour: "numeric",
    minute: date.getMinutes() !== 0 ? "2-digit" : undefined,
    hour12: true,
  });
}

/**
 * Convert a "HH:MM" 24-hour string → 12-hour display string.
 * @param {string} time24  e.g. "14:30"
 * @returns {string}       e.g. "2:30 PM"
 */
export function time24To12(time24) {
  const [hStr, mStr] = time24.split(":");
  let h = parseInt(hStr, 10);
  const m = parseInt(mStr, 10);
  const period = h >= 12 ? "PM" : "AM";
  h = h % 12 || 12;
  const mm = m > 0 ? `:${String(m).padStart(2, "0")}` : "";
  return `${h}${mm} ${period}`;
}

/**
 * Convert a "h:mm AM/PM" 12-hour string → "HH:MM" 24-hour string.
 * @param {string} time12  e.g. "2:30 PM"
 * @returns {string}       e.g. "14:30"
 */
export function time12To24(time12) {
  const [timePart, period] = time12.trim().split(" ");
  const [hStr, mStr = "0"] = timePart.split(":");
  let h = parseInt(hStr, 10);
  if (period?.toUpperCase() === "PM" && h !== 12) h += 12;
  if (period?.toUpperCase() === "AM" && h === 12) h = 0;
  return `${String(h).padStart(2, "0")}:${String(parseInt(mStr, 10)).padStart(2, "0")}`;
}


// ── Settings Toggle Helpers ──────────────────────────────────

/**
 * Switch the temperature unit and persist the choice.
 * @param {"C"|"F"} unit
 */
export function setTempUnit(unit) {
  if (unit !== "C" && unit !== "F") return;
  currentSettings.tempUnit = unit;
  saveSettings(currentSettings);
  document.dispatchEvent(new CustomEvent("settingsChanged", { detail: { ...currentSettings } }));
}

/**
 * Switch the time format and persist the choice.
 * @param {"12h"|"24h"} format
 */
export function setTimeFormat(format) {
  if (format !== "12h" && format !== "24h") return;
  currentSettings.timeFormat = format;
  saveSettings(currentSettings);
  document.dispatchEvent(new CustomEvent("settingsChanged", { detail: { ...currentSettings } }));
}

/**
 * Get a read-only copy of the current settings.
 * @returns {{ tempUnit: string, timeFormat: string }}
 */
export function getSettings() {
  return { ...currentSettings };
}
