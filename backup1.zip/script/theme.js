const html = document.documentElement;

// Load theme when page opens
window.addEventListener("DOMContentLoaded", () => {
    const savedTheme = localStorage.getItem("theme");

    if (savedTheme) {
        html.setAttribute("data-theme-mode", savedTheme);
    }
});

// Toggle theme
const darkToggleBtn = document.getElementById("darkToggle");

darkToggleBtn.addEventListener("click", updateTheme);

function updateTheme() {
    const currentTheme = html.getAttribute("data-theme-mode");

    if (currentTheme === "dark") {
        html.setAttribute("data-theme-mode", "light");
        localStorage.setItem("theme", "light");
    } else {
        html.setAttribute("data-theme-mode", "dark");
        localStorage.setItem("theme", "dark");
    }
}